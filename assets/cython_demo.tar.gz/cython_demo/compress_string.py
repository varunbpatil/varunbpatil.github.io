#
# Cython Demo
#
# Python application to read a user specified string and
# compress it using LZO
#

import lzo_compress

user_str = input()
lzo_compress.do_lzo_compress(user_str)
